/*
 * client and server share this 
 */

const int PORT=0x1234;
const int MSGSIZE=8192;
